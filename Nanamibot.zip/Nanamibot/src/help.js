const help = (prefix) => { 
	return `
❦═─⊱〘 𝐼𝑁𝐹𝑂 〙⊰══
║
╰─⊱ 𝐼𝐶𝐻𝐼 𝐵𝑂𝑇
╰─⊱ 11.0
╰─⊱ 𝑂𝑊𝑁𝐸𝑅 : Aidil Tipi
╰─⊱ wa.me/62895704959080
╰─⊱ 𝐵𝑖𝑔 𝑆𝑝𝑒𝑐𝑖𝑎𝑙 𝑡𝑜
╰─⊱ 𝑋𝑃𝑇𝑁
╰─⊱ 𝑅𝐼𝑆𝐾𝑌
╰─⊱ 𝐴𝐿𝑃𝐻𝐴
╰─⊱ 𝐷𝐸𝑁𝐼𝑆
║
▣═─⊱【 𝑴𝑬𝑵𝑼 𝑺𝑰𝑴𝑷𝑳𝑬 】⊰─══
║ 
╭─⊱*${prefix}listmenu*
║
▣═─⊱【 𝐿𝐼𝑆𝑇 𝑀𝐸𝑁𝑈 】⊰─══
║
╰─⊱ *${prefix}ownermenu*
╭─⊱ *${prefix}adminmenu*
  ╰─⊱ *${prefix}nsfwmenu*
  ╰─⊱ *${prefix}funmenu*
  ╰─⊱ *${prefix}mediamenu*
  ╰─⊱ *${prefix} makermenu*
  ╰─⊱ *${prefix}vipmenu*
  ╰─⊱ *${prefix}kerangmenu*
╰─⊱ *${prefix}animemenu*
╭─⊱ *${prefix}othermenu*
║
▣═══─⊱【 𝑂𝑇𝐻𝐸𝑅 】⊰─═══
║
╰─⊱ *${prefix}request [teksmu*
╭─⊱ *${prefix}setprefix*
  ╰─⊱ *${prefix}bugreport [teksmu]*
  ╰─⊱ *${prefix}listblock*
  ╰─⊱ *${prefix}iklan*
  ╰─⊱ *${prefix}runtime*
  ╰─⊱ *${prefix}info*
  ╰─⊱ *${prefix}rules*
  ╰─⊱ *${prefix}tnc*
  ╰─⊱ *${prefix}cekvip*
  ╰─⊱ *${prefix}daftarvip*
  ╰─⊱ *${prefix}addvip*
  ╰─⊱ *${prefix}dellvip*
  ╰─⊱ *${prefix}snk*
  ╰─⊱ *${prefix}darkadmin*
  ╰─⊱ *${prefix}darkgroup*
  ╰─⊱ *${prefix}listpremium*
  ╰─⊱ *${prefix}donate*
╰─⊱ *${prefix}ping*
╭─⊱ *${prefix}owner*
║
▣══─⊱ 【 𝑅𝑈𝑁𝑇𝐼𝑀𝐸 】 ⊰─══
║
╰─⊱ *STATUS BOT: Online*
╭─⊱ BOT ON: *24JAM *
║
▣══─ ⸨ NANAMI BOT ⸩ ─══▣`
}
exports.help = help
