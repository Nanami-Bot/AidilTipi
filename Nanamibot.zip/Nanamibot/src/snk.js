const snk = () => { 
	return `Syarat dan Ketentuan Bot *DARK* 
1. Kami tidak menyimpan gambar, video, file, audio, dan dokumen yang anda kirim
2. Kami tidak akan pernah meminta anda untuk memberikan informasi pribadi
3. Jika menemukan Bug/Error silahkan langsung lapor ke Owner bot
Kalian juga bisa menbuat vot sendiri caranya liat yt owner ya itu anker production
4. Apapun yang anda perintah pada bot ini, KAMI TIDAK AKAN BERTANGGUNG JAWAB!

Thanks !`
}
exports.snk = snk
